<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/stylemenu.css">
    <title>Menu - ADM</title>
</head>
<body>
    <section id="cxprincipal">
        <header id="banner"></header>
        <nav id="caixaamigo"></nav>
        <nav id="caixacomercio"></nav>
        <nav id="caixausuario"></nav>
        <nav id="caixaconsultaamigo"></nav>
        <nav id="caixaconsultacomercio"></nav>
        <nav id="caixaconsultausuario"></nav>
        <footer id="rodape"></footer>
    </section>
</body>
</html>