<?php
    $server = "localhost";
    $user = "root";
    $password = "";
    $bdname = "bdagendatb2024";
    $conn = mysqli_connect($server,$user,$password,$bdname);
?>