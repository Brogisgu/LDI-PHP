<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulte comércio</title>
</head>
<body>
    <?php
    include_once "../factory/conexao.php";
    $empresa = $_POST["cxpesquisa"];
    $consultar = "select from tbcomercio where empresa ='$empresa'";
    $executar = mysqli_query($conn,$consultar);
    ?>
    Contato:
    <input type="text" value="<?php echo $linha['contato']?> "> <br/>
    Empresa:
    <input type="text" value="<?php echo $linha['empresa']?> "> <br/>
    Telefone:
    <input type="text" value="<?php echo $linha['telefone']?> "> <br/>
    Email:
    <input type="text" value="<?php echo $linha['email']?> "> <br/>
</body>
</html>